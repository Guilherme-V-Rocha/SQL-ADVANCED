USE COMERCIO
GO

--# Fun��es

--1) Crie uma fun��o que informado o sexo (M, F) como par�metro retorne a sua descri��o (Masculino, Feminino).
CREATE FUNCTION FT_EX_1(@SEXO CHAR(1))
RETURNS VARCHAR(100)
BEGIN

	RETURN IIF(@SEXO = 'M' , 'Masculino', 'Feminino')
END
GO

DROP FUNCTION FT_EX_1
GO

SELECT dbo.FT_EX-1(SEXO) AS Sexo FROM CLIENTE
GO
--2) Crie uma fun��o (multi-statement table-valued function) que apresente o volume e o montante total de compras com as informa��es do cliente 
--(par�metro de entrada, c�digo do cliente), sendo:

-- c�digo;
-- nome completo;
-- data de nascimento (no formato PT_BR (DD/MM/YYYY);
-- sexo (categoriza��o -> M=Masculino; F=Feminino) utilize a fun��o criada no exerc�cio 01;
-- cidade;
-- estado; e
-- regi�o.
CREATE FUNCTION FT_EX2(@Cd_Cliente INT)
RETURNS TABLE
AS
	RETURN (
				SELECT
					C.idcliente AS 'Cod. Cliente',
					CONCAT(C.nome, ' ', C.sobrenome) AS 'Cliente',
					dbo.FT_EX_1(C.SEXO) AS SEXO,
					FORMAT(C.NASCIMENTO, 'dd/MM/yyyy') AS 'Data',
					(
						SELECT
							COUNT(NF.IDNOTA)
						FROM
							NOTA_FISCAL NF
						WHERE
							NF.id_cliente = C.idcliente
					) AS Volume,
					(
						SELECT
							SUM(NF.TOTAL)
						FROM
							NOTA_FISCAL NF
						WHERE
							NF.id_cliente = C.idcliente
					) AS 'Montante Total',
					(
						SELECT
						 CONCAT(E.estado, ' - ', E.regiao, ' - ', E.cidade, ' - ', E.rua)
						FROM 
							ENDERECO E
						WHERE
							E.id_cliente = C.idcliente
					) AS 'Endereco completo'
				FROM
					CLIENTE C
				WHERE
					C.IDCLIENTE = @Cd_Cliente
	);
GO

SELECT dbo.FN_EX2(2)
GO

--3) Crie uma fun��o que informado uma data como par�metro retorne o seu trimestre (1� TRI, 2� TRI, 3� TRI e 4� TRI).
CREATE FUNCTION FT_EX003(@DATA DATE)
RETURNS VARCHAR(15)
BEGIN

		RETURN CONCAT( CAST(DATEPART(QUARTER, @DATA) AS VARCHAR(15)), '� TRI' )
END


drop function FT_EX003

SELECT dbo.FT_EX003('1999-12-11')
GO

--4) Crie uma fun��o (multi-statement table-valued function) que gere um relat�rio que apresente o ano e o trimestre, seguido das seguintes m�tricas:

-- receita total;
-- custo total;
-- lucro total; e
-- margem de lucro (bruta).

--F�rmula = (Lucro / Receita total) * 100
	
--Exemplo: 
	
-- Receita total  : R$ 20.000
-- Custos         : R$ 13.000
-- Lucro          : R$ 20.000 - R$ 13.000 = R$ 7.000
-- Margem de Lucro: R$ 7.000 / R$ 20.000  = 0.35 x 100 = 35%
--A fun��o dever� receber como par�metro de entrada o ano e a percentual da margem de lucro e dever� retornar somente os anos e trimestres (utilize a fun��o criada no exerc�cio 03) cuja a lucratividade tenha alcan�ado um resultado superior ou igual a margem de lucro informada.
CREATE FUNCTION FT_EX4(@Ano INT , @PR_MR_Lucro FLOAT )
RETURNS TABLE
AS
	RETURN (
				SELECT
					YEAR(N.DATA) AS Ano,
					dbo.FT_EX003(N.DATA) AS Trimestre,
					SUM(I.TOTAL) AS 'Receita Total',
					(SUM(P.CUSTO_MEDIO * (I.QUANTIDADE))) AS Custo,
					(SUM(I.TOTAL) - (SUM(P.CUSTO_MEDIO * (I.QUANTIDADE)))) AS Lucro,
					((SUM(I.TOTAL) - (SUM(P.CUSTO_MEDIO * (I.QUANTIDADE)))) / SUM(I.TOTAL)) * 100 AS Margem
				FROM 
					NOTA_FISCAL N
					JOIN ITEM_NOTA I
					ON I.ID_NOTA_FISCAL = N.IDNOTA
					JOIN PRODUTO P
					ON P.IDPRODUTO = I.ID_PRODUTO
				WHERE 
					YEAR(N.DATA) = @Ano
				GROUP BY 
					YEAR(N.DATA), 
					dbo.FT_EX003(N.DATA)
				HAVING 
					((SUM(I.TOTAL) - (SUM(P.CUSTO_MEDIO * (I.QUANTIDADE)))) / SUM(I.TOTAL)) * 100 >= @PR_MR_Lucro
			
	);
GO

SELECT * FROM dbo.FT_EX4(2015, 20)
--5) Crie uma fun��o que informado duas datas (data inicial, data final) como par�metro retorne a diferen�a em dias.
CREATE FUNCTION FT_EX5(@DT_Inicio DATE, @DT_Fim DATE)
RETURNS VARCHAR(50)
BEGIN
    RETURN  DATEDIFF(day, @DT_Inicio, @DT_Fim);
END
GO

SELECT dbo.FT_EX5
GO

--6) Crie uma fun��o (multi-statement table-valued function) que informado o c�digo do cliente apresente a matriz RFM 
--(Rec�ncia, Frequ�ncia e Valor Monet�rio) do mesmo.
--Tempo para retorno (R) - dias desde a �ltima compra (utilize a fun��o criada no exerc�cio 05)
--Frequ�ncia (F) - N�mero total de compras
--Valor monet�rio (M) - quanto dinheiro total o cliente gastou.
CREATE FUNCTION FT_EX6()
RETURNS TABLE
AS
	RETURN (
		SELECT
			C.IDCLIENTE AS 'Cd. Cliente',
			C.NOME AS Cliente,
			dbo.FT_EX5(MAX(NF.DATA), GETDATE()) AS 'Tempo para retorno',
			COUNT(NF.IDNOTA) AS Frequencia,
			SUM(NF.TOTAL) AS 'Valor monetario'
		FROM
			NOTA_FISCAL NF
			JOIN CLIENTE C
				ON C.IDCLIENTE = NF.ID_CLIENTE
		GROUP BY
			C.IDCLIENTE,
			C.NOME 
	);
GO
