USE LOCADORA
GO

/* 01 - Criar uma SP, que informado a sua
categoria, liste os filmes e a quantidade
de vezes que cada filme foi locado.*/

CREATE PROCEDURE SP_LIST_FILME1(
    @categoriaId INT)
AS
BEGIN
    SELECT
        C.descricao AS Categoria,
        F.descricao AS Filme,
        F.duracao AS Tempo,
		F.valor AS Valor,
        COUNT(L.fitaId) AS Quantidade
    FROM
        CATEGORIA C
        JOIN FILME F
            ON F.categoriaId = C.id
        JOIN FITA FT
            ON FT.filmeId = F.id
        JOIN LOCACAO L
            ON L.fitaId = FT.id
    WHERE
        C.id = @categoriaId
    GROUP BY
        C.descricao,
        F.descricao,
        F.duracao,
		F.id,
		F.valor
END
GO

EXEC SP_LIST_FILME1 1
GO

/* 02 - Criar uma SP, que informado um cliente,
atualize o status para Ativo ou Inativo.*/

CREATE PROCEDURE SP_STATUS_CLIENTE (@status INT, @id INT)
AS
BEGIN
	UPDATE CLIENTE
		SET ativo = @status
	WHERE
		id = @id
END
GO

EXEC SP_STATUS_CLIENTE 1, 2
GO

/* 03 - Criar uma SP, que informado uma data
inicial e final, exiba a quantidade de
filmes locados, agrupadas por ano, m�s e
dia.*/

CREATE PROCEDURE SP_DT_IN_FINAL(@dataInicio DATE, @dataFinal DATE )
AS
BEGIN
	SELECT
        F.descricao AS Filme,
        F.duracao AS Tempo,
		F.valor AS Valor,
		COUNT(L.fitaId) AS Quantidade
    FROM
        FILME F
        JOIN FITA FT
            ON FT.filmeId = F.id
        JOIN LOCACAO L
            ON L.fitaId = FT.id
	WHERE
		L.dataLocacao BETWEEN @dataInicio AND @dataFinal
    GROUP BY
        F.descricao,
        F.duracao,
		F.valor,
		YEAR(L.dataLocacao),
		MONTH(L.dataLocacao),
		DAY(L.dataLocacao)
	ORDER BY
		F.descricao
END
GO

EXEC SP_DT_IN_FINAL '2019/11/01' , '2021/06/01'
GO
/* 04 - Criar uma SP, que atualize o valor de
todos os filmes de uma categoria
espec�fica.
(Exemplo um acr�scimo de 10% no valor de cada filme)*/

CREATE PROCEDURE SP_ATT_VALOR_FILME(@categoriaId INT)
AS
BEGIN
	UPDATE FILME
		SET valor += valor * 0.10
	WHERE
		categoriaId = @categoriaId
END
GO

EXEC SP_ATT_VALOR_FILME 2
GO

/* 05 - Criar uma SP para gerar um relat�rio de
loca��es de categoria de filmes,
agrupando a quantidade de loca��es por
ano e m�s.*/

CREATE PROCEDURE SP_RL_CATEGORIA_FILME(@categoriaId INT)
AS
BEGIN
	SELECT
		C.descricao AS Categoria,
		F.descricao AS Filme,
		COUNT(L.dataLocacao) AS Quantidade
    FROM
		FILME F
		JOIN CATEGORIA C
			ON C.id = F.categoriaId
		JOIN FITA FT
			ON FT.filmeId = F.id
		JOIN LOCACAO L 
			ON L.fitaId = FT.id
	WHERE
		C.id = @categoriaId
    GROUP BY
		C.descricao,
		F.descricao,
		YEAR(L.dataLocacao),
		MONTH(L.dataLocacao)
END
GO

EXEC SP_RL_CATEGORIA_FILME 1
GO