USE COMERCIO
GO

--Lista de Exerc�cios utilizando a base de dados COMERCIO: Procedimentos e Fun��es.

--# Procedimentos

--1) Crie um procedimento que apresente o volume e o montante total de vendas por regi�o e trimestre.

CREATE PROCEDURE EX_1
AS
BEGIN
	SELECT
		E.REGIAO AS Regi�o,
		COUNT(NF.IDNOTA) AS Volume,
		FORMAT(SUM(NF.TOTAL), 'C', 'pt-br') AS 'Total de Vendas',
		DATEPART(QUARTER, NF.DATA) AS Trimestre
	FROM 
		ENDERECO E
		JOIN CLIENTE C
			ON C.IDCLIENTE = E.ID_CLIENTE
		JOIN NOTA_FISCAL NF
			ON NF.ID_CLIENTE = C.IDCLIENTE
	GROUP BY
		E.REGIAO,
		DATEPART(QUARTER, NF.DATA) 
	ORDER BY
		COUNT(NF.IDNOTA) DESC
END
GO

DROP PROCEDURE EX_1
GO

EXEC EX_1
GO
--2) Crie um procedimento que apresente os top 10 clientes em volume de compras.
CREATE PROCEDURE EX_2
AS
BEGIN
	SELECT TOP 10
		C.IDCLIENTE AS 'Cod. Cliente',
		C.NOME AS Cliente,
		COUNT(NF.IDNOTA) AS Volume
	FROM
		NOTA_FISCAL NF
		JOIN CLIENTE C
			ON C.IDCLIENTE = NF.ID_CLIENTE
		GROUP BY
			C.IDCLIENTE,
			C.NOME
		ORDER BY
			COUNT(NF.IDNOTA) DESC
END
GO

DROP PROCEDURE EX_2
GO

EXEC EX_2
GO
--3) Crie um procedimento que mostre os clientes que n�o realizaram nenhuma compra.
CREATE PROCEDURE EX_3
AS
BEGIN
	SELECT 
		C.IDCLIENTE, 
		C.NOME, 
		C.SOBRENOME,
		NF.IDNOTA
	FROM 
		NOTA_FISCAL NF 
		RIGHT JOIN CLIENTE C
			ON C.IDCLIENTE = NF.ID_CLIENTE
	WHERE 
		NF.IDNOTA IS NULL
END
GO

DROP PROCEDURE EX_3
GO

EXEC EX_3
GO


--4) Crie um procedimento que apresente o faturamento e o faturamento acumulado por ano.
CREATE PROCEDURE EX_4
AS
BEGIN
	SELECT 
		YEAR(data) AS ANO,
		FORMAT(SUM(total), 'C', 'pt-br') AS FATURAMENTO,
		(
			SELECT
				FORMAT(SUM(total), 'C', 'pt-br')
			FROM
				NOTA_FISCAL NFI
			WHERE
				YEAR(NFI.data) <= YEAR(NF.data)
	
		) AS 'FAT. ACUMULADO'
	FROM 
		NOTA_FISCAL NF
	GROUP BY
		YEAR(data)
	ORDER BY
		YEAR(data)
END
GO

DROP PROCEDURE EX_4
GO

EXEC EX_4
GO

--5) Crie um procedimento que apresente os cinco produtos mais caros por categoria (par�metro de entrada) de produto.
ALTER PROCEDURE EX_5(@C_Produto VARCHAR(100))
AS
BEGIN
	SELECT TOP 5
		P.PRODUTO AS 'Nome Livros',
		C.NOME AS Categoria,
		FORMAT(MAX(P.VALOR), 'C', 'pt-br') AS Preco
	FROM
		CATEGORIA C
		JOIN PRODUTO P
			ON P.ID_CATEGORIA = C.IDCATEGORIA
	WHERE
		C.NOME LIKE  '%' + @C_Produto + '%'
	GROUP BY
		C.NOME,
		P.VALOR,
		P.PRODUTO
	ORDER BY
		P.VALOR DESC
END
GO

DROP PROCEDURE EX_5
GO

EXEC EX_5 'LIVROS'
GO
