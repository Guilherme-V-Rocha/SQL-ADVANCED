USE LOCADORA
GO

/*
01) Crie uma fun��o que informado dois valores retorne uma string informando se o n�mero �
par ou �mpar.
*/
CREATE FUNCTION FN_EX1(@valor INT)
RETURNS VARCHAR(10)
AS
BEGIN
	RETURN IF(@valor % 2 > 0 'Impar', 'Par')
END
GO

SELECT dbo.FN_EX1(1)
GO
/*
02) Crie uma fun��o que retorne o n�mero mais o nome do m�s em portugu�s (1 - Janeiro) de
acordo com o par�metro informado que deve ser uma data. Para testar, crie uma consulta que
retorne o cliente e m�s de loca��o (n�mero e nome do m�s).
*/
CREATE FUNCTION FN_EX2(@data DATETIME)
RETURNS VARCHAR(20)
AS
BEGIN
	RETURN CONCAT(MONTH(@data) , ' - ', UPPER(DATENAME(MONTH, @data)))
END
GO

SET LANGUAGE Portuguese
GO

SELECT dbo.FN_EX2(GETDATE())
GO

SELECT
	L.clienteId,
	C.nome AS CLIENTE,
	L.dataLocacao,
	dbo.FN_EX2(L.dataLocacao) AS Mes

FROM
	LOCACAO L
	JOIN CLIENTE C
		ON C.id = L.clienteId
	GO

 /*
03) Crie uma fun��o que retorne o n�mero mais o nome do dia da semana em portugu�s (1 -
Segunda), como par�metro de entrada receba uma data. Para testar, crie uma consulta que
retorne o c�digo do cliente, o nome do cliente e dia da semana da loca��o utilizando a fun��o
criada.
*/
CREATE FUNCTION FN_EX3(@data DATETIME)
RETURNS VARCHAR(20)
AS
BEGIN
	RETURN CONCAT(DATEPART(WEEKDAY, @data), ' - ', DATENAME(WEEKDAY, @data))
END
GO

SELECT dbo.FN_EX3(GETDATE())
GO

SELECT
	L.clienteId,
	C.nome AS Cliente,
	L.dataLocacao,
	dbo.FN_EX3(L.dataLocacao) as DiaSemana
FROM
	LOCACAO L
	JOIN CLIENTE C
		ON C.id = L.clienteId
GO


 
/*
04) Crie uma fun��o para retornar o gent�lico dos clientes de acordo com o estado onde
moram (ga�cho, catarinense ou paranaense), o par�metro de entrada deve ser a sigla do
estado. Para testar a fun��o crie uma consulta que liste o nome do cliente e gent�lico
utilizando a fun��o criada.
*/
CREATE FUNCTION FN_EX4(@uf CHAR(2))
RETURNS VARCHAR(20)
AS
BEGIN
	DECLARE @gentilico VARCHAR(20) = ''
	SET @gentilico =
	CASE @uf 
		WHEN 'PR' THEN 'paranaense'
		WHEN 'SC' THEN 'catarinese'
		WHEN 'RS' THEN 'gaucho'
		ELSE 'NI'
	END

	RETURN @gentilico
END
GO

SELECT dbo.FN_EX4('PR')
GO

UPDATE CLIENTE SET estado = 'RS' WHERE id NOT IN (1,2)
GO

SELECT 
	nome AS CLIENTE,
	dbo.FN_EX4(estado) AS gentilico
FROM 
	CLIENTE
GO

/*
05) Crie uma fun��o que retorne o CPF do cliente no formato ###.###.###-##. Para testar a
fun��o criada exiba os dados do cliente com o CPF formatado corretamente utilizando a
fun��o criada.
*/
CREATE FUNCTION FN_EX5(@cpf VARCHAR(11))
RETURNS VARCHAR(14)
AS
BEGIN
	RETURN CONCAT(
		LEFT(@cpf, 3),
		'.',
		SUBSTRING(@cpf, 4, 3),
		'.',
		SUBSTRING(@cpf, 7, 3),
		'.',
		RIGHT(@cpf, 2)
		)
END
GO

SELECT dbo.FN_EX5('5545554545')
GO

SELECT
	nome AS CLIENTE,
	dbo.FN_EX5(cpf) AS CPF
FROM
	CLIENTE
GO


/*
06) Crie uma fun��o que fa�a a compara��o entre dois n�meros inteiros. Caso os dois n�meros
sejam iguais a sa�da dever� ser �x � igual a y�, no qual x � o primeiro par�metro e y o segundo
par�metro. Se x for maior, dever� ser exibido �x � maior que y�. Se x for menor, dever� ser
exibido �x � menor que y�.
*/
CREATE FUNCTION FN_EX6(@x INT, @y INT)
RETURNS VARCHAR(60)
AS
BEGIN
	DECLARE @res VARCHAR(60) = ''

	IF(@x = @y)
		SET @res = 'x eh igual a y'
	ELSE IF (@x > @y)
		SET @res = 'x eh maior que y'
	ELSE
		SET @res = 'x eh menor que y'

	RETURN @res
END
GO

SELECT dbo.FN_EX6(2, 2)
GO

/*
07) Crie uma fun��o que calcule a f�rmula de Bhaskara. Como par�metro de entrada devem
ser recebidos 3 valores (a, b e c). Ao final a fun��o deve retornar �Os resultados calculados s�o
x e y�, no qual x e y s�o os valores calculados.
*/
CREATE FUNCTION FN_EX7(@a INT, @b INT, @c INT)
RETURNS VARCHAR(100)
AS
BEGIN
	DECLARE @x INT;
	DECLARE @y INT;
	DECLARE @delta FLOAT;

	SET @delta = (@b * @b) - (4 * @a * @c)

	SET	@x = (-@b + SQRT(@delta)) / (2 * @a);
	SET @y = (-@b - SQRT(@delta)) / (2 * @a);
	
	RETURN CONCAT('Os resultado calculados sao x e y: ', @x, ',', @y)
END
GO

SELECT dbo.FN_EX7(1,5,4)
GO
/*
08) Crie uma fun��o que informado a data de nascimento como par�metro retorne a idade da
pessoa em anos.
*/
CREATE FUNCTION FN_EX8(@data DATE)
RETURNS INT
AS
BEGIN
	RETURN FLOOR(DATEDIFF(DAY, @data, GETDATE()) / 365.25)
END
GO

SELECT dbo.FN_EX8('1986-05-22')
GO

/*
09) Fa�a uma fun��o que retorna o c�digo do cliente com a maior quantidade de loca��es por
ano/m�s. Observe que a fun��o dever� receber como par�metros um ano e um m�s. Deve ser
exibido a seguinte express�o: �O cliente XXXXXXX (c�d) � XXXXXXX (nome) foi o cliente que fez
a maior quantidade de loca��es no ano XXXX m�s XX com um total de XXX loca��es�.
*/

CREATE FUNCTION FN_EX9(@ano INT, @mes INT)
RETURNS VARCHAR(200)
AS
BEGIN
	DECLARE @id INT
	DECLARE @nome VARCHAR(100)
	DECLARE @qtdeLocacoes INT

	SELECT TOP 1
		@id = c.id,
		@nome = c.nome,
		@qtdeLocacoes = COUNT(*)
	FROM
		LOCACAO L
		JOIN CLIENTE C
			ON C.id = L.clienteId
	WHERE
		YEAR(dataLocacao) = @ano
		AND MONTH(dataLocacao) = @mes
	
	RETURN CONCAT(
		'O cliente ', @id, ' - ' @nome, 'foi o cliente que fez a maior quantidade de locacoes no ano ', @ano, 'mes ', @mes, 'com 
		um total de ', @qtdeLocacoes, 'locacoes'
	)
END
GO

SELECT dbo.FN_EX9(2019, 11)
GO

/*
10) DESAFIO: Crie uma fun��o que receba um n�mero de CPF sem separadores xxxxxxxxxxx (11
d�gitos) e verifique se o n�mero � um CPF v�lido ou n�o. Caso seja um CPF v�lido retorne o
mesmo formatado corretamente xxx.xxx.xxx-xx, caso n�o seja v�lido, retorne a frase �O CPF
digitado � inv�lido�
*/

CREATE FUNCTION FN_EX10(@cpf VARCHAR(11))
RETURNS VARCHAR(11)
AS
BEGIN
		DECLARE @cpfaux VARCHAR
		DECLARE @cont INT
		DECLARE @digito1 INT
		DECLARE @digito2 INT
		DECLARE @udg1 VARCHAR 
		DECLARE @udg2 VARCHAR
		SET @cont = 10

		SET @cpfaux = LTRIM(RTRIM(@cpf))
		SET @cpfaux = CAST(SUBSTRING(@cpfaux, 1, 9) AS INT)

		SET @udg1 = LTRIM(RTRIM(@cpf))
		SET @udg2 = LTRIM(RTRIM(@cpf))
		SET @udg1 = CAST(SUBSTRING(@cpfaux, 10, 1) AS INT)
		SET @udg1 = CAST(SUBSTRING(@cpfaux, 11, 1) AS INT)

		WHILE(@cont = 2 )
			BEGIN	
				SET @digito1 += @cpfaux * @cont
				SET @cont -= 1
			END
		SET @digito1 = @digito1 * 10
		SET @digito1 = @digito1 % 11
		WHILE(@cont = 3)
			BEGIN
				SET @digito2 += @cpfaux * @cont
				SET @cont -= 1
			END
		SET @digito2 += @digito1 * 2
		SET @digito2 = @digito2 * 10
		SET @digito2 = @digito2 % 11

		IF(@udg1 = @digito1 AND @udg2 = @digito2)
			RETURN CONCAT(
				LEFT(@cpf, 3),
				'.',
				SUBSTRING(@cpf, 4, 3),
				'.',
				SUBSTRING(@cpf, 7, 3),
				'.',
				RIGHT(@cpf, 2)
				)
		ELSE
			RETURN 'O CPF digitado � inv�lidO'
END
GO


SELECT dbo.FN_EX10('62337214078')
GO