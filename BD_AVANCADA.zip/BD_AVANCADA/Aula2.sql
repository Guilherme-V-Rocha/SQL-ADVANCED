USE LOCADORA
GO

IF MONTH(GETDATE()) IN (5, 12)
	SELECT '1 semetre '
ELSE
	SELECT '2 semestre '
GO

IF DATEPART(QUARTER , getDATE()) >= 3
	SELECT '2 Semestre'
ELSE
	SELECT '1 Semestre'
GO
--IF DATENAME(weekday, GETDATE()) IN ('S�bado', 'Domingo')
--       SELECT 'Final de Semana';
--ELSE 
--       SELECT 'Dia de Semana';

CREATE TABLE numeros(numero INT) GO

DECLARE @i INT = 0

WHILE @i < 50
BEGIN
	SET @i += 1
	INSERT INTO numeros VALUES(@i)
END
GO

SELECT * FROM numeros GO

SET NOCOUNT ON
DECLARE @contador INT = 1
DECLARE @i INT
SET @i = 0
WHILE @i < 50
BEGIN
	SET @i += 1
	SELECT
	 'Loop Iterecao ' +
	 CAST (@i AS CHAR(2)) +
	 '  Contador recente = ' + CAST(@contador AS CHAR(2))

	 IF @i = 3
		CONTINUE
	 IF @i = 5
		BREAK

	 SET @contador += 1
END
GO

SET NOCOUNT ON
DECLARE @d INT = 0
WHILE @d < 6
BEGIN
	SET @d += 1
	SELECT
		id,
		descricao
	FROM
		FILME
	WHERE
		id = @d
END
GO

SET NOCOUNT ON
DECLARE @d INT = 0
WHILE @d < 1
BEGIN
	SET @d += 1
	select top 6 * from filme order by id
END
GO