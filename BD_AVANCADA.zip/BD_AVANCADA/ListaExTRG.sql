USE LOJA_TRIGGER;
GO

--1. Crie um TRIGGER para baixar o estoque de um produto quando ele for vendido.

SELECT * FROM itempedido GO
SELECT * FROM produto GO

CREATE OR ALTER TRIGGER TGR_EX1
ON itempedido
AFTER INSERT
AS
BEGIN
	UPDATE produto SET
		produto.quantidade = produto.quantidade i.quantidade
	FROM
		inserted i
	WHERE
		produto.codproduto = i.codproduto
END
GO

--2. Crie um TRIGGER para criar um log dos CLIENTES modificados.
--Obs deleted e inserted, todo update e insert feito estara na tabela inserted e todo delete feito estara na tabela deleted que sao tabelas logicas

SELECT * FROM cliente GO
SELECT * FROM log GO

CREATE OR ALTER TRIGGER TGR_EX2
ON cliente
AFTER UPDATE
AS
BEGIN
	INSERT INTO
		log
	SELECT
		(SELECT ISNULL(MAX(codlog) + 1, 1) FROM log),
		CAST(GETDATE() AS DATE),
		CONCAT('Acao: Update | Cliente ID: ', i.codcliente)
	FROM
		inserted i
END
GO

--3. Crie um TRIGGER para criar um log de PRODUTOS atualizados.

CREATE OR ALTER TRIGGER TGR_EX3
ON produto
AFTER UPDATE
AS
BEGIN
	INSERT INTO
		log
	SELECT
		(SELECT ISNULL(MAX(codlog) + 1, 1) FROM log),
		CAST(GETDATE() AS DATE),
		CONCAT('Acao: Update | Cliente ID: ', i.codproduto)
	FROM
		inserted i
END
GO

--4. Crie um TRIGGER para criar um log quando n�o existe a quantidade do ITEMPEDIDO em estoque.

CREATE OR ALTER TRIGGER TRGR_EX04
ON itempedido
FOR INSERT
AS
BEGIN
	DECLARE @quantidade INT,
			@codproduto INT,
			@estoque INT,
			@descricao VARCHAR(255)

	SELECT
		@quantidade = i.quantidade,
		@codproduto = i.codproduto,
		@estoque = p.quantidade
	FROM	
		inserted i
		JOIN produto p
			ON p.codproduto = i.codproduto
	
	IF @estoque < @quantidade
	BEGIN
		SET @descricao = CONCAT('Produto sem estoque suficiente. ', @codproduto)
		ROLLBACK TRANSACTION
		EXEC SP_INSERE_LOG @descricao
		RETURN
	END

END;
GO

SELECT * FROM pedido
SELECT * FROM itempedido
SELECT * FROM produto
SELECT * FROM log
GO
--UPDATE produto SET quantidade = 10 WHERE codproduto = 2

INSERT INTO itempedido VALUES(7, 4, 10.90, 11, 2)

CREATE PROCEDURE SP_INSERE_LOG(@DESCRICAO VARCHAR(255))
AS
BEGIN
	INSERT INTO
		log
	VALUES(
		(SELECT ISNULL(MAX(codlog) + 1, 1) FROM log),
		GETDATE(),
		@DESCRICAO
	)
END;
GO

--5. Crie um TRIGGER para criar uma requisi��o de REQUISICAO_COMPRA quanto o estoque atingir 50% da venda mensal.
--6. Crie um TRIGGER para criar um log quando um ITEMPEDIDO for removido.

CREATE OR ALTER TRIGGER TRGR_EX06
ON 
FOR INSERT
AS
BEGIN

END
GO

--7. Crie um TRIGGER para criar um log quando o valor total do pedido for maior que R$ 1.000,00.
--8. Crie um TRIGGER para N�O deixar valores negativos serem INSERIDOS em ITEMPEDIDO, o valor m�nimo � �0�.
--9. Crie um TRIGGER que N�O permita que uma PESSOA com data de nascimento anterior � data atual seja inserida ou atualizada.
--10. Crie um TRIGGER para n�o permitir quantidade negativa na tabela ITEMPEDIDO.

SELECT * FROM pedido GO
SELECT * FROM itempedido GO
SELECT * FROM produto GO 