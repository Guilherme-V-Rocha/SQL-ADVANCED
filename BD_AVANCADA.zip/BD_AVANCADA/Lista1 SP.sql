USE LOCADORA
GO

/*
01) Exiba a quantidade total de loca��es de um determinado filme. (Exibir o id, nome do filme
e quantidade de loca��es)
*/
CREATE PROCEDURE SP_TL_LOCACOES(@NM_FILME VARCHAR(200))
AS
BEGIN
	SELECT
		F.id AS 'Codigo filme',
		F.descricao AS Filme,
		COUNT(L.fitaId) AS 'Quantidade de locacoes'
	FROM
		FILME F
		JOIN FITA FT
			ON  FT.filmeId = F.id
		JOIN LOCACAO L
			ON L.fitaId = FT.id
	WHERE
		F.descricao LIKE '%' +  @NM_FILME + '%'
	GROUP BY
		F.id,
		F.descricao
END
GO

EXEC SP_TL_LOCACOES it
GO

/*
02) Exiba todas as loca��es efetuadas por um determinando cliente. (Exibir o id, nome do
cliente e quantidade de loca��es)
*/

CREATE PROCEDURE SP_TL_LOCACOES_CLIENTE(@id INT)
AS
BEGIN
	SELECT
		C.id AS 'Codigo filme',
		C.nome AS Cliente,
		COUNT(L.fitaId) AS 'Quantidade de locacoes'
	FROM
		LOCACAO L
		JOIN CLIENTE C
			ON C.id = L.clienteId
	WHERE
		C.id = @id
	GROUP BY
		C.id,
		C.nome
END
GO

EXEC SP_TL_LOCACOES_CLIENTE 2
GO

/*
03) Calcule o valor total de loca��es para as categorias de filme com base nas loca��es do
m�s/ano (m�s e ano ser�o par�metros IN)
*/

CREATE PROCEDURE SP_TL_LOCACOES (@mes DATE, @ano DATE)
AS
BEGIN
	SELECT
		C.descricao AS Categoria,
		SUM(F.Valor) AS Total
	FROM
		FILME F
		JOIN CATEGORIA C
			ON C.id = F.categoriaId
		JOIN FITA FT 
			ON  FT.filmeId = F.id
		JOIN LOCACAO L
			ON L.fitaId = FT.id
	WHERE
		MONTH(L.dataLocacao) IN ( @mes )
		AND DAY(L.dataLocacao) IN ( @ano )
	GROUP BY
		C.descricao
END
GO

EXEC SP_TL_LOCACOES
GO

/*
04) Listar quais clientes precisam devolver filmes.
*/

CREATE PROCEDURE SP_LST_CLIENTE
AS
BEGIN
	SELECT
		C.id AS Codigo,
		C.nome AS Cliente

	FROM
		LOCACAO L
		JOIN CLIENTE C
			ON C.id = L.clienteId
	WHERE
		L.dataDevolucao IS NULL
END
GO

EXEC SP_LST_CLIENTE
GO

/*
05) Listar quais filmes nunca foram locados.
*/
CREATE PROCEDURE SP_LST_CLIENTE
AS
BEGIN
	SELECT
		F.id AS Codigo,
		F.descricao AS Filme
	FROM
		FILME F
		JOIN FITA FT
			ON FT.filmeId = F.id 
		JOIN LOCACAO L
			ON L.fitaId = FT.id
	WHERE
		L.dataLocacao IS NULL
END
GO

EXEC SP_LST_CLIENTE
GO

/*
06) Listar quais clientes nunca efetuaram uma loca��o.
*/
CREATE PROCEDURE SP_LST_CLIENTE
AS
BEGIN
	SELECT
		C.id AS Codigo,
		C.nome AS Cliente
	FROM
		LOCACAO L
		JOIN CLIENTE C
			ON C.id = L.clienteId
	WHERE
		L.dataLocacao IS NULL
END
GO

EXEC SP_LST_CLIENTE
GO

/*
07) Listar a data da �ltima loca��o de um determinado cliente.
*/
CREATE PROCEDURE SP_ULTIMA_LCC(@id INT)
AS
BEGIN
	SELECT TOP 1
		C.id AS Codigo,
		C.nome AS Cliente,
		L.dataLocacao AS 'Ultima Locacao'
	FROM
		LOCACAO	L
		JOIN CLIENTE C
			ON C.id = L.clienteId
	WHERE
		C.id = @id
	ORDER BY
		L.dataLocacao DESC
END
GO

EXEC SP_ULTIMA_LCC
GO
/*
08) Calcule o valor total de loca��es e o valor total de loca��es acumulado por m�s (ano ser�
par�metro IN)
*/

CREATE PROCEDURE SP_TL_LC(@ano DATE)
AS
BEGIN
	SELECT
		SUM(F.valor) AS 'Total Locacoes',
		MONTH(LC.dataLocacao) AS Meses,
		(
			SELECT
				SUM(F.valor)
			FROM
				FILME F
				JOIN FITA FT
					ON FT.filmeId = F.id
				JOIN LOCACAO L
					ON L.fitaId = FT.id
			WHERE
				MONTH(L.dataLocacao) < MONTH(LC.dataLocacao)
		) AS 'Total por mes'

		FROM
			FILME F
			JOIN FITA FT
				ON FT.filmeId = F.id
			JOIN LOCACAO LC
				ON LC.fitaId = FT.id
		WHERE
			YEAR(LC.dataLocacao) IN ( @ano)
		GROUP BY
			LC.dataLocacao
END
GO

EXEC SP_TL_LC
GO

/*
09) Listar a quantidade de loca��es por categoria de filme. Exibir cada categoria de filme sendo
uma coluna. (Conceito Pivot Table)
*/
CREATE PROCEDURE LT_QT_LC
AS 
BEGIN
	SELECT
		*
	FROM
	(
		SELECT
			C.descricao AS Categoria
		FROM
			LOCACAO L
			JOIN FITA FT
				ON FT.id = L.fitaId
			JOIN FILME F
				ON F.id = FT.filmeId
			JOIN CATEGORIA C
				ON C.id = F.categoriaId
	)  AS Tabela
	PIVOT
		(
			COUNT(Categoria)
			FOR Categoria IN ([Terror], [Drama], [Ficcao Cientifica], [Acao], [Comedia])
		) AS PVT_QT_LC
END
GO

/*
10) DESAFIO: Listar o ranking de filmes mais locados. (Conceito de Rank)
*/

CREATE PROCEDURE SP_EX_10
AS
BEGIN
	SELECT
		F.descricao,
		RANK() OVER (ORDER BY fitaId DESC) AS Rank 
	FROM
		LOCACAO L
		JOIN FITA FT
			ON FT.id = L.fitaId
		JOIN FILME F
			ON F.id = FT.filmeId
	GROUP BY
		F.descricao,
		fitaId
END
GO

EXEC SP_EX_10