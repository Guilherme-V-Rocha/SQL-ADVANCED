﻿/*
    # Lista de Exercícios - Views & Indexed Views
    # Disciplina: Banco de Dados Avançado
    # Prof.: Tiago José Marciano #datalover🖤
*/

USE BikeStores 
GO

/* 
01) Crie uma view para exibir o número de orders completed (pedidos concluídos) 
por store (loja) e staff (vendedor).
Order status: 
1 = Pending; 
2 = Processing; 
3 = Rejected; 
4 = Completed
*/

CREATE VIEW EX_01
AS
SELECT
	COUNT(ord.shipped_date) AS 'Pedidos Concluido',
	ord.store_id AS 'Cod da loja',
	st.store_name AS Loja,
	ord.staff_id AS 'Cod do vendedor',
    CONCAT(sta.first_name, ' ', sta.last_name) AS 'Vendedor',
	ord.order_status AS Completed
FROM 
	sales.orders ord 
    JOIN sales.stores st
		ON st.store_id = ord.store_id
	JOIN sales.staffs sta
		ON sta.staff_id = ord.staff_id
	WHERE
		ord.order_status = 4
	GROUP BY
		ord.store_id,
		st.store_name,
		ord.staff_id,
		sta.first_name,
		sta.last_name,
		order_status
	HAVING
		COUNT(ord.shipped_date) > 0
GO

/*
2) Crie uma view para exibir o número de orders (pedidos) por ano, mês 
(order_date) e order status (situação). O número de orders deverá ser
apresentado em colunas representadas por cada order status (situação).
Order status: 
1 = Pending; 
2 = Processing; 
3 = Rejected; 
4 = Completed
*/

CREATE VIEW EX_02
AS
	SELECT
		YEAR(DateOrders) AS Ano,
		MONTH(DateOrders) AS Mes,
		orderst.[1] AS Pending,
		orderst.[2] AS Processing,
		orderst.[3] AS Rejected,
		orderst.[4] AS Completed
	FROM 
	(
		SELECT
			order_id AS NumberOrders,
			order_date AS DateOrders,
			order_status AS OrderStatus
		FROM 
			sales.orders
	) AS EX02
	PIVOT(
		COUNT(NumberOrders)  FOR OrderStatus IN ([1] , [2], [3], [4])
	) AS orderst
GO

/*
3) Crie uma view para exibir a revenue (receita) e a revenue accumulated 
(receita acumulada) de orders completed (pedidos concluídos) por ano.
*/
CREATE VIEW EX_03
AS
SELECT 
	FORMAT
	(
		(
			SELECT
				SUM(list_price)
			FROM
				sales.order_items
		), 'C', 'pt-br'
	) AS Receita,
	FORMAT(SUM(ord_it.list_price), 'C', 'pt-br') AS 'Receita Acumulada',
	YEAR(ord.order_date) AS Ano, 
	ord.order_status AS Completed
FROM
	sales.orders ord
	JOIN sales.order_items ord_it
		ON ord_it.order_id = ord.order_id
	WHERE
		ord.order_status = 4
	GROUP BY
		ord.order_status,
		YEAR(ord.order_date)
GO

/*
4) Crie uma view para exibir o volume orders completed (volume de pedidos concluídos)
e a revenue (receita) por products (produtos) e model year (modelo do ano).
*/

CREATE VIEW EX_04
AS
SELECT
	FORMAT(SUM(ord_it.list_price), 'C', 'PT-BR') AS Receita,
	prd.product_id AS Cod_Prod,
	prd.product_name AS Produto,
	prd.model_year,
	COUNT(ord.order_status) AS VolumeCompleted
FROM
	sales.orders ord
	JOIN sales.order_items ord_it
		ON ord_it.order_id = ord.order_id
	JOIN production.products prd
		ON prd.product_id = ord_it.product_id
	WHERE
		ord.order_status = 4
	GROUP BY
		prd.product_id,
		prd.product_name,
		prd.model_year,
		ord.order_status
GO


/*
5) Crie uma view para exibir o volume orders completed (volume de pedidos concluídos)
e a revenue (receita) por brands (marcas).
*/

CREATE VIEW EX_05
AS
SELECT
	COUNT(ord.order_status) AS VolumeCompleted,
	FORMAT(SUM(ord_it.list_price), 'C', 'PT-BR') AS Receita,
	brd.brand_name AS Marcas
FROM
	sales.orders ord
	JOIN sales.order_items ord_it
		ON ord_it.order_id = ord.order_id
	JOIN production.products prd
		ON prd.product_id = ord_it.product_id
	JOIN production.brands brd
		ON brd.brand_id = prd.brand_id
	WHERE
		ord.order_status = 4
	GROUP BY
		brd.brand_name
GO

/*
6) Crie uma view para exibir o volume orders completed (volume de pedidos concluídos)
e a revenue (receita) por categories (categorias).
*/

CREATE VIEW EX_06
AS
SELECT
	COUNT(ord.order_status) AS VolumeCompleted,
	FORMAT(SUM(ord_it.list_price), 'C', 'PT-BR') AS Receita,
	cat.category_name AS Categoria
FROM
	sales.orders ord
	JOIN sales.order_items ord_it
		ON ord_it.order_id = ord.order_id
	JOIN production.products prd
		ON prd.product_id = ord_it.product_id
	JOIN production.categories cat
		ON cat.category_id = prd.category_id
	WHERE
		ord.order_status = 4
	GROUP BY
		cat.category_name
GO

/*
7) Crie uma view para exibir o volume orders completed (volume de pedidos concluídos)
e a revenue (receita) por state (estado) e city (cidade).
*/

CREATE VIEW EX_07
AS
SELECT
	COUNT(ord.order_status) AS VolumeCompleted,
	FORMAT(SUM(ord_it.list_price), 'C', 'PT-BR') AS Receita,
	cust.state AS Estado,
	cust.city AS Cidade
FROM
	sales.orders ord
	JOIN sales.order_items ord_it
		ON ord_it.order_id = ord.order_id
	JOIN sales.customers cust
		ON cust.customer_id = ord.customer_id
	GROUP BY
		cust.state,
		cust.city
GO

/*
8) Crie uma view para exibir a data da primeira e última order (pedido)
de cada customer (cliente).
*/

CREATE VIEW EX_08
AS
SELECT 
	MIN(ord.order_date) AS FirstOrder,
	MAX(ord.order_date) AS LastOrder,
	cust.customer_id AS Cod_Customer,
	CONCAT(cust.first_name, ' ', cust.last_name) AS Cliente
FROM
	sales.orders ord
	JOIN sales.customers cust
		ON cust.customer_id = ord.customer_id
	GROUP BY
		cust.customer_id,
		CONCAT(cust.first_name, ' ', cust.last_name)
GO

/*
9) Crie uma indexed view para exibir o volume orders completed (volume de pedidos concluídos),
a revenue (receita), o discounts (total de descontos) e a percentage discounts 
(percentual de descontos) por ano e trimestre.
*/

CREATE VIEW EX_09
WITH SCHEMABINDING
AS
SELECT 
	COUNT(ord.order_status) AS VolumeCompleted,
	FORMAT(SUM(ord_it.list_price),'C','PT-BR') AS Revenue,
	SUM(ord_it.discount) AS Discounts,
	YEAR(ord.order_date) AS Year,
	DATEPART(quarter, ord.order_date) AS Quarter
FROM
	sales.orders ord
	JOIN sales.order_items ord_it
		ON ord_it.order_id = ord.order_id
	GROUP BY
		YEAR(ord.order_date),
		DATEPART(quarter, ord.order_date)
GO